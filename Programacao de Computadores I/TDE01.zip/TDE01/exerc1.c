/* ---- TDE 01
   ---- Exercicio 01     
   ---- Rafaela Mumbach Buenos
   ---- V01 - 13/03/2024
*/

#include <stdio.h>

int main(){
	float val1, val2;
    printf("Digite dois valores: ");
    scanf("%f %f", &val1, &val2);

    printf("A media aritmetica dos dois valores eh: %.2f", (val1+val2)/2);
    
    return 0;
}                